const fs = require("fs");
const path = require("path");

// Read validation config
const configPath = "validation-config.json";
let config = { enabledValidations: {} };
if (fs.existsSync(configPath)) {
    config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
} else {
    console.warn("Warning: No validation-config.json found. Using default settings.");
}

// Extract enabled validation categories
const enabled = config.enabledValidations;

// Get job name from argument
const jobName = process.argv[2]?.replace(".xml", "");
if (!jobName) {
    console.error("Usage: node typo-validation.js </path/jobname.xml>");
    process.exit(1);
}

// Define file paths
const files = {
    log: `${jobName}.log`,
    validation: `${jobName}-validation.log`,
    eqn: `${jobName}.eqn`,
    fn: `${jobName}.FN`,
    overlap: `${jobName}-overlap.log`
};

// Function to read file content safely
const readFileSafe = (filePath) => {
    try {
        return fs.readFileSync(filePath, "utf-8");
    } catch (err) {
        console.warn(`Warning: Could not read ${filePath}`);
        return "";
    }
};

const removeDuplicates = (errors) => {
    const seen = new Set();
    return errors.filter(error => {
        const key = JSON.stringify(error);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
};

const parseNeoPageMessages = (content) => {
    const neoPageRegex = /\[NeoPage\|\d+\|BEGIN\]\s*Message:\s*(.*?)\s*\[NeoPage\|\d+\|END\](?:\s*Size:\s*(\d+))?(?:\s*Count:\s*(\d+))?(?:\s*Remarks:\s*(.*))?/gs;
    const messages = [];
    let match;

    while ((match = neoPageRegex.exec(content)) !== null) {
        const [, message, size, count, remarks] = match;

        const entry = {
            message: message.trim(),
        };

        if (size) entry.size = parseInt(size, 10);
        if (count) entry.count = parseInt(count, 10);
        if (remarks) entry.remarks = remarks.trim();

        messages.push(entry);
    }

    return messages;
};

// ** Parse `.log` file **
const parseLogFile = (content) => {
    const errors = [];

    if (enabled.missingCharacters) {
        const missingCharRegex = /Missing character: There is no (.+?) \(U\+([\dA-F]+)\) in font/g;
        let match;
        while ((match = missingCharRegex.exec(content)) !== null) {
            errors.push({
                type: "Missing Character",
                character: match[1],
                unicode: `U+${match[2]}`
            });
        }
    }

    if (enabled.underfullHbox) {
        const underfullHboxRegex = /Underfull \\hbox \(badness (\d+)\) in paragraph at lines (\d+)--(\d+)/g;
        let match;
        while ((match = underfullHboxRegex.exec(content)) !== null) {
            errors.push({
                type: "Underfull hbox",
                badness: match[1],
                lineRange: `${match[2]}-${match[3]}`
            });
        }
    }

    if (enabled.undefinedControlSequence) {
        const undefinedControlRegex = /! Undefined control sequence\./g;
        if (undefinedControlRegex.test(content)) {
            errors.push({ type: "Undefined Control Sequence" });
        }
    }

    if (enabled.mismatchedEnvironments) {
        const mismatchedEnvRegex = /! LaTeX Error: \\begin\{(.+?)\} ended by \\end\{(.+?)\}/g;
        let match;
        while ((match = mismatchedEnvRegex.exec(content)) !== null) {
            errors.push({ type: "Mismatched Environments", expected: match[1], found: match[2] });
        }
    }

    if (enabled.fileNotFound) {
        const fileNotFoundRegex = /! LaTeX Error: File '(.+?)' not found./g;
        let match;
        while ((match = fileNotFoundRegex.exec(content)) !== null) {
            errors.push({ type: "File Not Found", file: match[1] });
        }
    }

    if (enabled.fatalFontIssues) {
        const fontErrorRegex = /! Font .+? not loadable: Metric \(TFM\) file not found\./g;
        if (fontErrorRegex.test(content)) {
            errors.push({ type: "Fatal Font Issue" });
        }
    }

    if (enabled.texCapacityExceeded) {
        const texCapacityRegex = /! TeX capacity exceeded, sorry \[.+?\]/g;
        if (texCapacityRegex.test(content)) {
            errors.push({ type: "TeX Capacity Exceeded" });
        }
    }

    if (enabled.missingBeginDocument) {
        const missingBeginDocumentRegex = /! LaTeX Error: Missing \\begin\{document\}\./g;
        if (missingBeginDocumentRegex.test(content)) {
            errors.push({ type: "Missing \\begin{document}" });
        }
    }

    if (enabled.misplacedAlignment) {
        const misplacedAlignRegex = /! Misplaced \\noalign\.|! Misplaced \\omit\./g;
        if (misplacedAlignRegex.test(content)) {
            errors.push({ type: "Misplaced Alignment (\\noalign or \\omit)" });
        }
    }

    if (enabled.undefinedReferences) {
        const undefinedRefRegex = /Warning: Reference .+? undefined/g;
        if (undefinedRefRegex.test(content)) {
            errors.push({ type: "Undefined Reference" });
        }
    }

    if (enabled.mathModeErrors) {
        const mathModeErrorRegex = /! Missing \$ inserted\./g;
        if (mathModeErrorRegex.test(content)) {
            errors.push({ type: "Math Mode Error (Missing $)" });
        }
    }

    if (enabled.packageConflicts) {
        const packageConflictRegex = /! Package .+? Error:/g;
        let match;
        while ((match = packageConflictRegex.exec(content)) !== null) {
            errors.push({ type: "Package Conflict", package: match[0] });
        }
    }

    if (enabled.includeErrors) {
        const includeErrorRegex = /! I can't find file '(.+?)'\./g;
        let match;
        while ((match = includeErrorRegex.exec(content)) !== null) {
            errors.push({ type: "Include/Input Error", file: match[1] });
        }
    }

    if (enabled.runawayArguments) {
        const runawayArgRegex = /! Runaway argument\?/g;
        if (runawayArgRegex.test(content)) {
            errors.push({ type: "Runaway Argument Error" });
        }
    }
    
    errors.push(...parseNeoPageMessages(content));

    return errors;
};

const parseTextHeightExceedance = (content) => {
    if (!enabled.contentExceedsTextheight) return [];

    const errors = [];
    const threshold = 6; // Set threshold to 6pt
    const lines = content.split(/\n+/); // Split content by new lines

    for (let i = 0; i < lines.length; i++) {
        const match = lines[i].match(/Overfull\s+\\vbox\s*\(\s*([\d.]+)pt\s+too high\s*\)/);

        if (match) {
            const excessHeight = parseFloat(match[1]);
            if (excessHeight < threshold) continue; // Skip if below threshold
            let page = "Unknown"; // Default page number
            const nextLineMatch = lines[i + 1]?.match(/Page End\s+(\d+)/);

            if (nextLineMatch) {
                page = nextLineMatch[1]; // Extract page number
            }

            errors.push({
                type: "Content Exceeds Textheight",
                excessHeight: `${match[1]}pt`,
                page
            });
        }
    }
    return errors;
};

const parseTableOverlap = (content) => {
    if (!enabled.tableOverlap) return [];
    
    const errors = [];
    const tableRegex = /begin\{neotable\}\{(.+?)\}([\s\S]*?)end\{neotable\}\{\1\}/g;
    const overfullRegex = /Overfull \\hbox \((\d+\.\d+)pt too wide\)|Overfull \\vbox \((\d+\.\d+)pt too high\)/g;
    
    let match;
    while ((match = tableRegex.exec(content)) !== null) {
        const tableId = match[1];
        const tableContent = match[2];
        let issueMatch;
        
        while ((issueMatch = overfullRegex.exec(tableContent)) !== null) {
            errors.push({
                type: "TABLE_OVERLAP",
                tableId,
                issue: issueMatch[1] ? `Overfull hbox (${issueMatch[1]}pt too wide)` : `Overfull vbox (${issueMatch[2]}pt too high)`
            });
        }
    }
    return errors;
};

const parseBlankPages = (content) => {
    if (!enabled.blankPages) return [];
    const errors = [];
    const normalizedContent = content.replace(/\[\s*(\d+)\s*\n+\s*\]/g, '[$1]');
    const lines = normalizedContent.split(/\n+/);
    let currentPage = null;
    let pageContent = [];
    
    for (let i = 0; i < lines.length; i++) {
        if (/^Page Start (\d+)/.test(lines[i])) {
            currentPage = lines[i].match(/^Page Start (\d+)/)[1];
            pageContent = [];
            continue;
        }
        
        if (/^Page End (\d+)/.test(lines[i]) && currentPage !== null) {
            const filteredContent = pageContent.filter(line => {
                return !line.match(/^\[\s*\d+\s*\]$/);
            });
            
            if (filteredContent.length === 0) {
                errors.push({ type: "Blank Page", page: currentPage });
            }
            
            currentPage = null;
            continue;
        }
        
        let cleanLine = lines[i].replace(/\[\s*\d+\s*\]/g, "").trim();
        
        if (currentPage !== null && cleanLine !== "") {
            pageContent.push(cleanLine);
        }
    }
    
    return errors;
};

// ** Parse `-validation.log` file **
const parseValidationLog = (content) => {
    const errors = [];

    if (enabled.columnWidthExceedance) {
        const columnWidthExceedanceRegex = /p\.\s*(\d+),\s*col\.(\d+),\s*line\s*(\d+),\s*Line exceeds the ColumnWidth ([\d.]+)pt/g;
        let match;
        while ((match = columnWidthExceedanceRegex.exec(content)) !== null) {
            errors.push({
                type: "Column Width Exceedance",
                page: match[1],
                column: match[2],
                line: match[3],
                exceededWidth: `${match[4]}pt`
            });
        }
    }

    if (enabled.looseLineStretch) {
        const looseLineStretchRegex = /p\.\s*(\d+),\s*col\.(\d+),\s*line\s*(\d+),\s*Loose line stretch=([\d]+)%/g;
        let match;
        while ((match = looseLineStretchRegex.exec(content)) !== null) {
            errors.push({
                type: "Loose Line Stretch",
                page: match[1],
                column: match[2],
                line: match[3],
                stretchPercentage: `${match[4]}%`
            });
        }
    }

    return errors;
};

// ** Parse `-validation.log` file for Page/Column End Hyphenation Issues **
const parsePageColumnEndHyphenation = (content) => {
    if (!enabled.pageColumnEndHyphenation) return [];

    const errors = [];
    const regex = /p\.\s*(\d+),\s*col\.(\d+),\s*line\s*(\d+),\s*Page\/Column end Hyphenation/g;

    let match;
    while ((match = regex.exec(content)) !== null) {
        errors.push({
            type: "Page/Column End Hyphenation",
            page: match[1],
            column: match[2],
            line: match[3]
        });
    }

    return errors;
};

// ** Parse `-validation.log` file for Consecutive Hyphens Issues **
const parseConsecutiveHyphens = (content) => {
    if (!enabled.consecutiveHyphens) return [];

    const errors = [];
    const regex = /p\.\s*(\d+),\s*col\.(\d+),\s*line\s*(\d+),\s*Consecutive Hyphens: more than 2/g;

    let match;
    while ((match = regex.exec(content)) !== null) {
        errors.push({
            type: "Consecutive Hyphens",
            page: match[1],
            column: match[2],
            line: match[3]
        });
    }

    return errors;
};

// ** Parse `-validation.log` file for Short Pages **
const parseShortPages = (content) => {
    if (!enabled.ShortPages) return [];

    const errors = [];
    const regex = /p\.\s*(\d+),\s*col\.(\d+),\s*line\s*(\d+),\s*SHORT PAGE: (only \d+ lines)/g;

    let match;
    while ((match = regex.exec(content)) !== null) {
        errors.push({
            type: "SHORT PAGE",
            page: match[1],
            column: match[2],
            line: match[3],
            msg: match[4]
        });
    }

    return errors;
};

// Parse overlap log
const parseOverlapLog = (content) => {
    if (!enabled.glyphOverlap) return [];
    
    const errors = [];
    const overlapRegex = /Overlap: Char '(.+?)' at \((\d+\.\d+), (\d+\.\d+)\) overlaps with '(.+?)' at \((\d+\.\d+), (\d+\.\d+)\)/g;
    let match;
    
    while ((match = overlapRegex.exec(content)) !== null) {
        errors.push({
            type: "GLYPH_OVERLAP",
            char: match[1],
            charPosition: { x: parseFloat(match[2]), y: parseFloat(match[3]) },
            overlapsWith: match[4],
            overlapPosition: { x: parseFloat(match[5]), y: parseFloat(match[6]) }
        });
    }
    return errors;
};

const parseEquations = (content) => {
    if (!enabled.equations) return [];

    const equations = {};
    const ColumnWidthLimit = config.ColumnWidthLimit || 252;

    // Regex Patterns
    const widthRegex = /(?:EQ Number|Eq\.No): \{\((\d+)\)\} EQ ID: \{(\w+)\} width of ([\d.]+)pt/g;
    const revisedWidthRegex = /Eq\.No: \{\((\d+)\)\} EQ ID: \{(\w+)\} Revised width of ([\d.]+)pt/g;
    const fontSizeReducedRegex = /Eq\.No: \{\((\d+)\)\} EQ ID: \{(\w+)\} Two point Font size reduced for this equation/g;

    let match;

    // Extract actual width
    while ((match = widthRegex.exec(content)) !== null) {
        const eqNumber = match[1];
        const eqID = match[2];
        const actualWidth = parseFloat(match[3]);
        const exceedsLimit = actualWidth > ColumnWidthLimit;

        equations[`${eqNumber}_${eqID}`] = {
            eqNumber,
            eqID,
            actualWidth: `${actualWidth}pt`,
            revisedWidth: null,
            fontSizeReduced: false,
            exceedsColumnTextWidth: exceedsLimit
        };
    }

    // Extract revised width
    while ((match = revisedWidthRegex.exec(content)) !== null) {
        const eqNumber = match[1];
        const eqID = match[2];
        const revisedWidth = parseFloat(match[3]);

        if (equations[`${eqNumber}_${eqID}`]) {
            equations[`${eqNumber}_${eqID}`].revisedWidth = `${revisedWidth}pt`;
        }
    }

    // Extract font size reduction
    while ((match = fontSizeReducedRegex.exec(content)) !== null) {
        const eqNumber = match[1];
        const eqID = match[2];

        if (equations[`${eqNumber}_${eqID}`]) {
            equations[`${eqNumber}_${eqID}`].fontSizeReduced = true;
        }
    }

    return Object.values(equations);
};

// ** Parse `.FN` file **
const parseFootnoteFile = (content) => {
    if (!enabled.footnotes) return [];

    const footnotes = [];
    const footnoteRegex = /Footnote Citation Number = (\w+) Citation Page Number = (\d+)/g;
    let match;
    while ((match = footnoteRegex.exec(content)) !== null) {
        footnotes.push({
            citationNumber: match[1],
            pageNumber: match[2]
        });
    }
    return footnotes;
};

const generateHtmlReport = (report) => {
    const outputFile = `${jobName}-validation-report.html`;

    let htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Validation Report - ${jobName}</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; background-color: #f9f9f9; color: #333; }
            h1 { color: #2c3e50; text-align: center; }
            .container { max-width: 900px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
            .error { color: #e74c3c; font-weight: bold; }
            .warning { color: #f39c12; font-weight: bold; }
            .info { color: #2980b9; font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #34495e; color: white; }
            tr:nth-child(even) { background-color: #f2f2f2; }
            tr:hover { background-color: #f1c40f; color: black; }
            .collapsible { background-color: #3498db; color: white; cursor: pointer; padding: 12px; width: 100%; border: none; text-align: left; outline: none; font-size: 18px; margin-top: 10px; }
            .active, .collapsible:hover { background-color: #2980b9; }
            .content { display: none; padding: 0 20px; overflow: hidden; background-color: #f9f9f9; border-left: 4px solid #3498db; margin-bottom: 10px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Validation Report - ${jobName}</h1>
    `;

    const errorCategories = Object.keys(report.errors);
    errorCategories.forEach(category => {
        if (report.errors[category].length > 0) {
            htmlContent += `<button class="collapsible">${category.toUpperCase()} (${report.errors[category].length})</button>`;
            htmlContent += `<div class="content"><table><tr><th>Type</th><th>Details</th></tr>`;
            
            report.errors[category].forEach(error => {
                const severityClass = error.type && typeof error.type === "string" ? (
                    error.type.includes("Missing") ? "error" :
                    error.type.includes("Warning") ? "warning" : "info"
                ) : "info"; // Default to "info" if type is missing or invalid                

                htmlContent += `<tr>
                    <td class="${severityClass}">${error.type}</td>
                    <td>${JSON.stringify(error, null, 2)}</td>
                </tr>`;
            });

            htmlContent += `</table></div>`;
        }
    });

    htmlContent += `
        </div>
        <script>
            const collapsibles = document.querySelectorAll(".collapsible");
            collapsibles.forEach(button => {
                button.addEventListener("click", function() {
                    this.classList.toggle("active");
                    const content = this.nextElementSibling;
                    content.style.display = content.style.display === "block" ? "none" : "block";
                });
            });
        </script>
    </body>
    </html>`;

    // Save the HTML report
    fs.writeFileSync(outputFile, htmlContent);
    console.log(`HTML report saved as ${outputFile}`);
};


// Read file contents
const logContent = readFileSafe(files.log);
const validationContent = readFileSafe(files.validation);
const eqnContent = readFileSafe(files.eqn);
const fnContent = readFileSafe(files.fn);
const overlapContent = readFileSafe(files.overlap);

// Parse files and generate the report
const report = {
    jobName,
    errors: {
        log: removeDuplicates([
            ...parseLogFile(logContent),
            ...parseTextHeightExceedance(logContent),
            ...parseBlankPages(logContent),
            ...parseTableOverlap(logContent)
        ]),
        validation: removeDuplicates([
            ...parseValidationLog(validationContent),
            ...parsePageColumnEndHyphenation(validationContent),
            ...parseConsecutiveHyphens(validationContent),
            ...parseShortPages(validationContent)
        ]),
        equations: removeDuplicates(parseEquations(eqnContent)),
        footnotes: removeDuplicates(parseFootnoteFile(fnContent)),
        glyphOverlap: removeDuplicates(parseOverlapLog(overlapContent))
    }
};

// Save as JSON file
const outputFile = `${jobName}-validation-metrics.json`;
fs.writeFileSync(outputFile, JSON.stringify(report, null, 2));

generateHtmlReport(report);

console.log(`Validation metrics saved to ${outputFile}`);


