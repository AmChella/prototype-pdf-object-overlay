local M = {}

-- Open just the overlap log file
local overlap_log = io.open(tex.jobname .. "-overlap.log", "w")

-- Simple table to store glyphs for current processing unit
local current_glyphs = {}

local function check_overlap(g1, g2)
    local threshold = 2
    local x_overlap = g1.x < g2.x + g2.width - threshold and g2.x < g1.x + g1.width - threshold
    local y_overlap = g1.y > g2.y - g2.height + threshold and g2.y > g1.y - g1.height + threshold
    return x_overlap and y_overlap
end

local function to_pt(sp_value)
    return sp_value / 65536
end

function M.track_glyphs(head, groupcode)
    local x_pos = 72
    local base_y = 700
    
    -- Clear the current glyphs for this processing unit
    current_glyphs = {}
    
    for n in node.traverse(head) do
        if n.id == node.id("glyph") then
            local width = to_pt(n.width)
            local height = to_pt(n.height)
            local depth = to_pt(n.depth)
            
            local glyph_info = {
                char = unicode.utf8.char(n.char),
                unicode = n.char,
                x = x_pos,
                y = base_y,
                width = width,
                height = height,
                depth = depth
            }

            table.insert(current_glyphs, glyph_info)
            
            x_pos = x_pos + width
        elseif n.id == node.id("kern") then
            x_pos = x_pos + to_pt(n.kern)
        elseif n.id == node.id("glue") then
            x_pos = x_pos + to_pt(n.width)
        elseif n.id == node.id("hlist") then
            x_pos = x_pos + to_pt(n.width)
        end
    end

    -- Check for overlaps only within the current group of glyphs
    for i = 1, #current_glyphs do
        for j = i + 1, #current_glyphs do
            if check_overlap(current_glyphs[i], current_glyphs[j]) then
                overlap_log:write(string.format(
                    "Overlap: Char '%s' at (%.2f, %.2f) overlaps with '%s' at (%.2f, %.2f)\n",
                    current_glyphs[i].char, current_glyphs[i].x, current_glyphs[i].y,
                    current_glyphs[j].char, current_glyphs[j].x, current_glyphs[j].y
                ))
            end
        end
    end

    return head
end

function M.process_pre_linebreak(head)
    return M.track_glyphs(head, "pre_linebreak_filter")
end

function M.process_hpack(head, groupcode)
    return M.track_glyphs(head, "hpack_filter")
end

function M.register_callbacks()
    luatexbase.add_to_callback("pre_linebreak_filter", M.process_pre_linebreak, "track_glyphs_pre_linebreak")
    luatexbase.add_to_callback("hpack_filter", M.process_hpack, "track_glyphs_hpack")
    -- Removed pre_output_filter callback entirely
end

-- Make sure to close the log file when TeX job is finished
luatexbase.add_to_callback("finish_pdffile", function() 
    if overlap_log then
        overlap_log:close()
    end
end, "close_overlap_log")

return M